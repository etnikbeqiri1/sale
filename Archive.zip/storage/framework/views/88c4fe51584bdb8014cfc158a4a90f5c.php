<?php $__env->startSection('content'); ?>
    <div class="max-w-md mx-auto bg-white rounded-lg shadow-md p-8">
        <h1 class="text-2xl font-bold mb-6">Item Pricing Details</h1>
        <ul class="space-y-4">
            <li class="flex items-start">
                <span class="font-semibold mr-2">ID:</span>
                <span><?php echo e($itemPricing->id); ?></span>
            </li>
            <li class="flex items-start">
                <span class="font-semibold mr-2">Name:</span>
                <span><?php echo e($itemPricing->name); ?></span>
            </li>
            <li class="flex items-start">
                <span class="font-semibold mr-2">Enabled:</span>
                <span><?php echo e($itemPricing->enabled); ?></span>
            </li>
            <li class="flex items-start">
                <span class="font-semibold mr-2">Created At:</span>
                <span><?php echo e($itemPricing->created_at); ?></span>
            </li>
            <li class="flex items-start">
                <span class="font-semibold mr-2">Updated At:</span>
                <span><?php echo e($itemPricing->updated_at); ?></span>
            </li>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/etnik/Desktop/larv/rest-saleforce-laravel_2/resources/views/item_pricing/show.blade.php ENDPATH**/ ?>