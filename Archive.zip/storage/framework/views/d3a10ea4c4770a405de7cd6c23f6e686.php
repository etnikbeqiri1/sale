<?php $__env->startSection('content'); ?>
    <div class="max-w-md mx-auto bg-white rounded-lg shadow-md p-8">
        <h1 class="text-2xl font-bold mb-6">Create Price</h1>
        <form method="POST" action="<?php echo e(route('prices.store')); ?>" class="space-y-4">
            <?php echo csrf_field(); ?>
            <div class="flex flex-col">
                <label for="name" class="text-lg font-semibold mb-2">Name:</label>
                <input required type="text" id="name" name="name" class="border border-gray-300 rounded-md py-2 px-4 focus:outline-none focus:border-blue-500">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="flex flex-col">
                <label for="price" class="text-lg font-semibold mb-2">Price:</label>
                <input required type="number" step="0.01" id="price" name="price" class="border border-gray-300 rounded-md py-2 px-4 focus:outline-none focus:border-blue-500">
                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="flex flex-col">
                <label  for="start_price" class="text-lg font-semibold mb-2">Start Price:</label>
                <input required type="number" step="0.01" id="start_price" name="start_price" class="border border-gray-300 rounded-md py-2 px-4 focus:outline-none focus:border-blue-500">
                <?php $__errorArgs = ['start_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-4">
                <label for="enabled" class="block text-gray-700 font-semibold mb-2">Enabled:</label>
                <input type="hidden" name="enabled" value="0">
                <input type="checkbox" id="enabled" name="enabled" value="1" checked>
            </div>
            <div class="flex flex-col">
                <label for="item_pricing_id" class="text-lg font-semibold mb-2">Item Pricing:</label>
                <select id="item_pricing_id" name="item_pricing_id" class="border border-gray-300 rounded-md py-2 px-4 focus:outline-none focus:border-blue-500">
                    <?php $__currentLoopData = $itemPricings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemPricing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($itemPricing->id); ?>"><?php echo e($itemPricing->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['item_pricing_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 transition-colors duration-200">Create</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/etnik/Desktop/larv/rest-saleforce-laravel_2/resources/views/price/create.blade.php ENDPATH**/ ?>