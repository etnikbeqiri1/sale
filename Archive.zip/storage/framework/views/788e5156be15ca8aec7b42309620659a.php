<?php $__env->startSection('content'); ?>
    <div class="container mx-auto">
        <div class="max-w-md mx-auto bg-white rounded-lg shadow-md p-4">
            <h1 class="text-2xl font-bold mb-6">Price Details</h1>
            <ul class="divide-y divide-gray-200 space-y-4">
                <li class="flex items-start">
                    <span class="font-semibold w-24">ID:</span>
                    <span><?php echo e($price->id); ?></span>
                </li>
                <li class="flex items-start">
                    <span class="font-semibold w-24">Name:</span>
                    <span><?php echo e($price->name); ?></span>
                </li>
                <li class="flex items-start">
                    <span class="font-semibold w-24">Price:</span>
                    <span><?php echo e($price->price); ?></span>
                </li>
                <li class="flex items-start">
                    <span class="font-semibold w-24">Start Price:</span>
                    <span><?php echo e($price->start_price); ?></span>
                </li>
                <li class="flex items-start">
                    <span class="font-semibold w-24">Enabled:</span>
                    <span><?php echo e($price->enabled ? 'Yes' : 'No'); ?></span>
                </li>
                <li class="flex items-start">
                    <span class="font-semibold w-24">Item Pricing ID:</span>
                    <span><?php echo e($price->item_pricing_id); ?></span>
                </li>
                <li class="flex items-start">
                    <span class="font-semibold w-24">Created At:</span>
                    <span><?php echo e($price->created_at); ?></span>
                </li>
                <li class="flex items-start">
                    <span class="font-semibold w-24">Updated At:</span>
                    <span><?php echo e($price->updated_at); ?></span>
                </li>
            </ul>
            <div class="mt-8">
                <a href="<?php echo e(route('prices.index')); ?>" class="inline-block px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors duration-200">Back to All Prices</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/etnik/Desktop/larv/rest-saleforce-laravel_2/resources/views/price/show.blade.php ENDPATH**/ ?>