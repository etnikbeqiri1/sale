<?php $__env->startSection('content'); ?>
    <h1>Product List</h1>
    <a href="<?php echo e(route('products.create')); ?>">Create</a>
    <table>
        <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Internal Name</th>
            <th>Price</th>
            <th>Image</th>
            <th>Stock</th>
            <th>Created At</th>
            <th>Updated At</th>
            <th>action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product->id); ?></td>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->internal_name); ?></td>
                <td><?php echo e($product->price); ?></td>
                <td><?php echo e($product->image); ?></td>
                <td><?php echo e($product->stock); ?></td>
                <td><?php echo e($product->created_at); ?></td>
                <td><?php echo e($product->updated_at); ?></td>
                <td>
                    <form method="POST" action="<?php echo e(route('products.destroy', $product->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/etnik/Desktop/larv/rest-saleforce-laravel_2/resources/views/product/index.blade.php ENDPATH**/ ?>