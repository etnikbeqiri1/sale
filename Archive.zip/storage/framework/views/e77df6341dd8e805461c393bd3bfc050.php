<?php $__env->startSection('content'); ?>
    <div class="max-w-md mx-auto bg-white rounded-lg shadow-md p-8">
        <h1 class="text-2xl font-bold mb-6">Item Details</h1>
        <ul class="space-y-4">
            <li class="flex items-center">
                <span class="text-gray-700 font-semibold mr-2">ID:</span> <?php echo e($item->id); ?>

            </li>
            <li class="flex items-center">
                <span class="text-gray-700 font-semibold mr-2">Name:</span> <?php echo e($item->name); ?>

            </li>
            <li class="flex items-center">
                <span class="text-gray-700 font-semibold mr-2">State:</span> <?php echo e($item->state); ?>

            </li>
            <li class="flex items-center">
                <span class="text-gray-700 font-semibold mr-2">Enabled:</span> <?php echo e($item->enabled); ?>

            </li>
            <li class="flex items-center">
                <span class="text-gray-700 font-semibold mr-2">Item Pricing ID:</span> <?php echo e($item->item_pricing_id); ?>

            </li>
            <li class="flex items-center">
                <span class="text-gray-700 font-semibold mr-2">Created At:</span> <?php echo e($item->created_at); ?>

            </li>
            <li class="flex items-center">
                <span class="text-gray-700 font-semibold mr-2">Updated At:</span> <?php echo e($item->updated_at); ?>

            </li>
        </ul>
        <div class="mt-8">
            <a href="<?php echo e(route('items.index')); ?>" class="inline-block px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors duration-200">Back to All Items</a>
        </div>
        <?php $__env->stopSection(); ?>
    </div>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/etnik/Desktop/larv/rest-saleforce-laravel_2/resources/views/item/show.blade.php ENDPATH**/ ?>