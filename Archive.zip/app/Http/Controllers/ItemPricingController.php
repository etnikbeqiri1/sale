<?php

namespace App\Http\Controllers;

use App\Models\Item;
use App\Models\ItemPricing;
use App\Models\Price;
use Illuminate\Http\Request;

class ItemPricingController extends Controller
{
    public function index()
    {
        $itemPricings = ItemPricing::all();
        return view('item_pricing.index', compact('itemPricings'));
    }

    public function show($id)
    {
        $itemPricing = ItemPricing::findOrFail($id);
        return view('item_pricing.show', compact('itemPricing'));
    }

    public function create()
    {
        return view('item_pricing.create');
    }

    public function store(Request $request)
    {
        $itemPricing = ItemPricing::create($request->all());
        return redirect()->route('item_pricings.show', $itemPricing->id);
    }

    public function edit($id)
    {
        $itemPricing = ItemPricing::findOrFail($id);
        return view('item_pricing.edit', compact('itemPricing'));
    }

    public function update(Request $request, $id)
    {
        $itemPricing = ItemPricing::findOrFail($id);
        $itemPricing->update($request->all());
        return redirect()->route('item_pricings.show', $itemPricing->id);
    }

    public function destroy($id)
    {
        ItemPricing::destroy($id);
        return redirect()->route('item_pricings.index');
    }
}
